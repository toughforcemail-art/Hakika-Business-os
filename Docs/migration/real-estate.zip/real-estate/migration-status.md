# Migration status

| Area | Status | Notes |
|---|---|---|
| Shell and navigation foundation | Scaffolded | Typed contracts created; no legacy behavior migrated |
| Pages and forms | Not audited | Empty states remain honest |
| Data repositories and services | Not audited | No production queries added |
| Actions and audit events | Not audited | No mutations added |
