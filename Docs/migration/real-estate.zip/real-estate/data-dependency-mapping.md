# Data dependency mapping

Future repositories must receive trusted server context containing user, organization, company and application identity. Browser-provided scope identifiers must not select tenant data. Totals and rows must use the same scoped query.
