# Action mapping

Mutation actions are intentionally unimplemented. Each future action must map to a server action/service, permission, audit event, validation contract and failure state.
