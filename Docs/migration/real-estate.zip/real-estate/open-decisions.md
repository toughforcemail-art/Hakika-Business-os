# Open decisions

- Which legacy application/version is authoritative?
- Which legacy routes and source files are in scope?
- Which domain fields and workflows must be preserved exactly?
- Which roles map to the new permission catalogue?
- Which company-scoped records may Platform Super Admin inspect by deliberate context selection?
