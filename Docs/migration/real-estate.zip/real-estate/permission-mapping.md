# Permission mapping

The typed catalogue lives at `frontend/src/modules/real-estate/permissions/catalog.ts`. Navigation declarations are UX metadata; server-side permission checks remain mandatory. Read-only access must not be implemented by merely hiding mutation controls.
