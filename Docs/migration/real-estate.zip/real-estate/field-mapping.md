# Field mapping

No fields are mapped before the legacy audit. Future mappings must identify source field, target field, type, requiredness, normalization, tenant ownership and evidence.
