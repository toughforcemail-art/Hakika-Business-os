# Page and feature matrix

Every future record must capture inputs, buttons, row/bulk actions, dialogs, tabs, filters, exports, API calls, tables, permissions, tenant fields, validation, loading/empty/error states, responsive behavior, evidence and open questions.

Current foundation status: `Scaffolded` only. No legacy feature is marked implemented.
